/*
 *  arch/arm/plat-omap/include/mach/param.h
 *
 */

#ifdef CONFIG_OMAP_32K_TIMER_HZ
#define HZ	CONFIG_OMAP_32K_TIMER_HZ
#endif
