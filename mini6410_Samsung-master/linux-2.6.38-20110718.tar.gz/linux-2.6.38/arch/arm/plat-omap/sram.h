#ifndef __PLAT_OMAP_SRAM_H__
#define __PLAT_OMAP_SRAM_H__

extern int __init omap_sram_init(void);

#endif /* __PLAT_OMAP_SRAM_H__ */
